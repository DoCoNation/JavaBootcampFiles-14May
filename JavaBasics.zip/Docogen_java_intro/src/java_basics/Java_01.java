package java_basics;

public class Java_01 {

	public static void main(String[] args) {
		// A variable is a container that stores a value.
		int mango_pickle = 12;
		String fruit = "Mango";
		
		/* 
		  Rules for declaring a variable name
		   and the second rule
		  */
		
		// Rules for declaring a variable name
		
		//1)Must not begin with a digit.
//		int 123mango = 12;
		//2) Name is case sensitive
		int no_of_apples = 10;
		int No_of_apples = 15;
//		String name = "Aryan";
//		String Name = "aryan";
		
//		System.out.println(no_of_apples);
//		System.out.println(No_of_apples);
		
		//3) Should not be a keyword
//		int if = 0;
//		4) Can contain alphabets and digits 
//		int no_of_apples = 12;
		
		
		// Primitive Data Types 
		
		// int , float, char, boolean
		
		// For Decimal Values
		double var1 = 12.435;
		float var2 = (float)12.23;
		float var3 = 12.23f;
		
		// For integer values
		int var4 = 10;
		long var5 = 123214l;
		
		// Boolean 
//		boolean present = true;
		boolean present = false;
		
//		NON PRIMITIVE DATA TYPE
		// String - for storing set of characters
		String name = "Aryan Bhandari";
		// ARRAYS
	}

}
