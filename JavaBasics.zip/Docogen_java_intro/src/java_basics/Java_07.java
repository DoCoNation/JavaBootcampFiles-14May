package java_basics;

import java.util.Scanner;

public class Java_07 {

	public static void main(String[] args) {
Brain b1 = new Brain() ;
b1.setChip_no(2021);
System.out.println(b1.getChip_no());
	}

}

class Brain {
	Scanner sc = new Scanner(System.in);
	
	String name ;
	private int chip_no = 2019;
	private String pass = "aryan@doconation";
	
	public int getChip_no() {
		return chip_no;
	}
	public void setChip_no(int chip_no) {
		System.out.println("Enter the password to set the chip number");
		String pass = sc.nextLine();
		if(pass.equals(this.pass)) {
			this.chip_no = chip_no;
			System.out.println("You Have Successfully changed the chip_no");
		}
		else {
			System.out.println("Wrong Password");
		}
		
		
	}
	
	
}


