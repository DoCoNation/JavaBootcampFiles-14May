package java_basics;

public class Java_06 {

	public static void main(String[] args) {
		
//		Robot r1 = new Robot("Aryan",2019);
		
		Fighter f1 = new Fighter();
		f1.walk();
	}

}

class Robot {
	String name ;
	int chip_no ;
	int steps;
	int model_no = 4444;
	
	Robot() {
		System.out.println("Robot is Created");
	}
	
	Robot(String name, int chip_no) {
		this();	// call constructor of the same class
		this.name  = name;
		this.chip_no = chip_no;
		System.out.println("Name "+ name+ ", Chip_No " + chip_no);
		this.walk(60);
	}
	
	public void walk() {
		System.out.println("Robot is Walking");
	}
	public void walk(int steps) {
		System.out.println("Robot Walked "+ steps +" Steps");
	}
}

class Dancer extends Robot{
	
}

class Fighter extends Robot {
	
	
	Fighter() {
//		super("Aryan",2010);
//		System.out.println(super.model_no);
		super.walk();
	}
	
	public void punch() {
		System.out.println("Fighter Robot Punches");
	}
	
	// Method Overriding - Run Time Polymorphism
	@Override
	public void walk() {
		System.out.println("Fighter Robot is walking");
	}
}


//class Parent {
//	int property = 10;
//	
////	Parent() {
////		System.out.println("From Parent");
////	}
//	
//	
//}
//class Child extends Parent{
//	
//	// Method Overloading - Compile Time PolyMorphism
//	public void show() {
//		System.out.println(property);
//	}
//	public void show(int x) {
//		System.out.println("From chil " + x);
//	}
//}