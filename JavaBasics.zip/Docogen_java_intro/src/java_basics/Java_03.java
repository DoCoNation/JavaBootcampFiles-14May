package java_basics;

public class Java_03 {

	public static void main(String[] args) {
		// If - else conditional statements
		
//		int age = 18;
//		boolean DL = false;
		// true - 1
		// false - 0
		// 1* 0 = 0
//		if(age>=18 && DL==true) {
//			System.out.println("You can drive");
//		}
//		else {
//			System.out.println("You cannot drive");
//		}
		
		int number = 5;
		// 5%2 
		if((number&1) == 0) {
			System.out.println("Even");
		}
		else {
//			System.out.println("Not even");
		}
		
		// Types of Loops 
		// while loop
		
		int i = 5;
//		while (i>0) {
//			System.out.println("Docogen");
//			i--;
//		}
		
		// do while loop
		int n = 5;
		
//		while (n<5) {
//		System.out.println("Printing");
//		n++;
//	}
//		do {
//			if(n==5) {
//				System.out.println("Printing Limit Exceeded");
//			}
//			n++;
//		}while(i<5);
	
		// for loop
		int count= 0;
		for (int j = 0; j < 5; j++) {
			for (int j2 = 0; j2 < 6; j2++) {
				System.out.println("i : "+i + " j : "+ j);
				count++;
			}
		}
		System.out.println(count);
		
	}
}

