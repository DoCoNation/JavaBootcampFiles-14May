package java_basics;

import java.util.Arrays;

public class Java_04 {

	public static void main(String[] args) {
		// Methods
//		int num1 =10;
//		int num2 = 20;
//		System.out.println(addn(num1,num2));
		
		// Arrays - it is an indexed collection of fixed homogeneous data type
//		int[] arr = new int[5];
//		arr[0] = 5;
//		arr[1] = 4;
//		arr[2] = 3;
//		int[] arr = {1,2,3,4,5};
		
//		System.out.println(arr[2]);
		
//		Arrays.sort(arr);
//		System.out.println("length " + arr.length);
//		for (int i = 0; i < arr.length; i++) {
//			System.out.println(arr[i]);
//		}
//		
		
		// for each
//		for(int any: arr) {
//			System.out.println(x);
//		}
		
		// 2D Array
		// if row = col => sq. matrix
		
//		int[][] arr2 = new int[5][5];
		
	
		// addition of matrices
		int[][] mat1 = {{1,2,3},
						{4,5,6},
						{7,8,9}
};
		int row1 = 3;
		int cols1 = 3;
	
	int[][] mat2 = {{3,2,1},
					{1,2,6},
					{1,2,3}
	};
	int row2 = 3;
	int cols2 = 3;
	
	int[][] addedMat = new int[row1][cols1];
	
	if(row1==row2 && cols1==cols2) {
		// addition
		for (int i = 0; i < row1; i++) {
			for (int j = 0; j < cols1; j++) {
				addedMat[i][j] = mat1[i][j] + mat2[i][j];
				System.out.print(addedMat[i][j]+ " ");
			}
			System.out.println();
		}
	}
}
	// Methods
//	public static int addn(int n1, int n2 ) {
//		int ans = n1+n2;
//		
//		return ans;
//	}
}
