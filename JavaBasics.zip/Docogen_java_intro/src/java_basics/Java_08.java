package java_basics;

public class Java_08 {

	public static void main(String[] args) throws MyException {
		// Exception
//		int a[] = {1,2,3};
//		System.out.println(a[5]);
		
		try {
			throw new MyException();
		}
		catch(MyException e) {
			System.out.println(e.getMessage());
		}
		catch(ArithmeticException e) {
			
		}
		catch(Exception e) {
			
		}
		finally {
			System.err.println("Finally ran");
		}
	}

}

class MyException extends Exception {
	@Override
	public String getMessage() {
		return "This is myException custom message";
	}
}