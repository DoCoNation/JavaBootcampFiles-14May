package java_basics;

public class Java_05 {

	public static void main(String[] args) {
		// Introduction to OOPS
//		Car c1 = new Car();
//		c1.startEngine();
//		System.out.println(c1.model_no);
		
		// String and its methods
//		String var = "Docogen";
//		String s = new String("Docogen");
		
//		if(var.equals(s)) {
//			System.out.println("Strings are equal");
//		}
//		else 
//		{
//			System.out.println("Strings are not equal");
//		}
		
		String var = "Doconation";
		System.out.println(var.length());
		System.out.println(var.indexOf("c"));
		System.out.println(var.charAt(2));
		System.out.println(var.substring(3,6));
	}

}

class Car {
	// Data members or fields 
	int model_no = 2019;
	
	
	// Methods of a class
	public static void startEngine () {
		System.out.println("Car is starting");
	}
}