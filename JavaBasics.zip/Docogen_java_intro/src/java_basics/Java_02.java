package java_basics;

import java.util.Scanner;

public class Java_02 {

	public static void main(String[] args) {
		
	// Reading Input From User
	Scanner sc = new Scanner(System.in);
//	System.out.println("Enter a String");
//	System.out.print("Value will be");
	 
	// Taking input of integer type
//	int var = sc.nextInt();
//	System.out.println("Your Value is " + var);
	
	// Taking input of float type
//		float var = sc.nextFloat();
//		System.out.println("Your Value is " + var);
	
	// Taking input of String type 
//	String var = sc.next();
//	System.out.println("Your Value is " + var);
		
	// OPERATORS
	//Arithmetic Operators [+, -, *, /, %, ++, --]
//	int a = 10;
//	int b =15;
//	a += b;
//	a = a+b;
//	int ans = a/0;
//	double a = 10;
//	double b = 15;
//	double ans = a / b;
	
//	%  : 
//	int a = 4;
//	int b = 3;
//	int ans = a + b;

	// increment ++
//	int a = 4;
//	a--; // 3
//	a--; // a = 2
//	int b = 3;
//	b--; // 2
//	int ans = a + b;
	
	
		
	//Assignment Operators [=, +=]
	int a = 10;
	int b = 10;
	
//	System.out.println(ans);
		
	//Comparison Operators [==, >=, <=]
//	System.out.println(a<b);
	
	//Logical Operators => [&&, ||, !]
		
//		if a person above 18 && a person have DL
//	if a person ! above 18 => he cannot drive 
	System.out.println(a != b);
	
	}

}
